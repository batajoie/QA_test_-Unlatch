from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.get("https://www.legalife.fr")
my_element = driver.find_element_by_xpath("//a[@title='Inscrivez-vous']")
my_element.click()
WebDriverWait(driver, 30).until(
    EC.text_to_be_present_in_element_value('Inscription')
)

email_input = driver.find_element_by_name('email')
email_input.send_keys("joy@unlyntch.com")

form_sub = driver.find_element_by_xpath("//a[@title='Inscription']")
form_sub.click()